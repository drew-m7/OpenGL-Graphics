#include<GL/glut.h>
#include<GL/gl.h>
#include<GL/glu.h>

void myRender(){
	//set display window's background color 
	glClearColor(0.0, 0.0, 0.0, 0.0); 
	//clears our buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//perform any other matrix transformations here

	// Line width for the black lines within the diamond
	glLineWidth(4);
	// Each set of 3 vertices form a triangle for the diamond
	glBegin(GL_TRIANGLES);
		// Left base of diamond
		glColor3f(1.0f, 0.0f, 0.0f); // Red
        glVertex2f(0.0, -0.75);
		glColor3f(0.0f, 1.0f, 0.0f); // Green
        glVertex2f(-0.5, 0.0);
		glColor3f(0.0f, 1.0f, 1.0f); // Cyan
        glVertex2f(-0.166, 0.0);
		
		// Middle base of diamond
		glColor3f(0.0f, 1.0f, 1.0f); // Cyan
        glVertex2f(-0.166, 0.0);
		glColor3f(0.0f, 1.0f, 1.0f); // Cyan
        glVertex2f(0.166, 0.0);
		glColor3f(1.0f, 0.0f, 0.0f); // Red
        glVertex2f(0.0, -0.75);		
		
		// Right bottom of diamond
        glColor3f(0.0f, 1.0f, 1.0f); // Cyan
        glVertex2f(0.166, 0.0);
	    glColor3f(0.0f, 0.0f, 1.0f); // Blue
        glVertex2f(0.5, 0.0);
	    glColor3f(1.0f, 0.0f, 0.0f); // Red
        glVertex2f(0.0, -0.75);

		// Top of diamond triangles
		// Left top
		glColor3f(0.0f, 1.0f, 0.0f);
		glVertex2f(-0.5, 0.0);
		glColor3f(0.0f, 1.0f, 1.0f);
		glVertex2f(-0.333, 0.2);
		glVertex2f(-0.166, 0.0);
		// Left middle top
		glVertex2f(-0.166, 0.0);
		glVertex2f(-0.333, 0.2);
		glVertex2f(0.0, 0.2);
		// Middle top
		glVertex2f(0.0, 0.2);
		glVertex2f(-0.166, 0.0);
		glVertex2f(0.166, 0.0);
		//Right middle top
		glVertex2f(0.0, 0.2);
		glVertex2f(0.166, 0.0);
		glVertex2f(0.333, 0.2);
		// Right top
		glVertex2f(0.166, 0.0);
		glVertex2f(0.333, 0.2);
		glColor3f(0.0f, 0.0f, 1.0f);
		glVertex2f(0.5, 0.0);
    glEnd();

	// Black lines inside diamond
	glBegin(GL_LINES);
		glColor3f(0.0f, 0.0f, 0.0f);
		glVertex2f(0.0, -0.75);
		glVertex2f(0.166, 0.0);
		glVertex2f(0.0, -0.75);
		glVertex2f(-0.166, 0.0);
		glVertex2f(-0.5, 0.0);
		glVertex2f(0.5, 0.0);
		glVertex2f(0.333, 0.2);
		glVertex2f(0.166, 0.0);
		glVertex2f(0.166, 0.0);
		glVertex2f(0.0, 0.2);
		glVertex2f(0.0, 0.2);
		glVertex2f(-0.166, 0.0);
		glVertex2f(-0.166, 0.0);
		glVertex2f(-0.333, 0.2);
	glEnd();

	//ensures our objects are drawn right away
	glFlush(); 

	//if we are using double buffering
	glutSwapBuffers(); 
}

int main(int argc, char ** argv )
{
	glutInit(&argc, argv); //process arguments

	//Initialize buffers
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE ); 
	
	//Sets some initial stuff
	glutInitWindowPosition(400, 200 ); 
	glutInitWindowSize(640, 480);

	//Creates window
	static int window = glutCreateWindow( "Hello, Computer Graphics, Drew Martin!"); 

	//Display callback function, etc. myRender()
	glutDisplayFunc(myRender);

	//Enters main processing loop
	glutMainLoop(); 

	exit(0);
}