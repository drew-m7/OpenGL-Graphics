#include<GL/glut.h>
#include<GL/gl.h>
#include<GL/glu.h>

void myRender(){
	//set display window's background color 
	glClearColor(0.0, 0.0, 0.0, 0.0); 
	//clears our buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//perform any other matrix transformations here

	glLineWidth(3);
	glBegin(GL_LINES);
		// COLOR: Cyan for the lines within the base of diamond and left and right top
		glColor3f(0.0f, 1.0f, 1.0f);

		glVertex2f(0.0, -0.75);
		glVertex2f(0.25, 0.0);
		glVertex2f(0.0, -0.75);
		glVertex2f(-0.25, 0.0);
		glVertex2f(0.0, 0.0);
		glVertex2f(0.0, -0.75);
		glVertex2f(-0.5, 0.0);
		glVertex2f(-0.375, 0.2);
		glVertex2f(0.5, 0.0);
		glVertex2f(0.375, 0.2);
	glEnd();

	glBegin(GL_LINE_LOOP);
		// COLOR: Cyan for the top middle
		glColor3f(0.0f, 1.0f, 1.0f);

		glVertex2f(-0.375, 0.2);
		glVertex2f(-0.25, 0.0);
		glVertex2f(-0.125, 0.2);
		glVertex2f(0.0, 0.0);
		glVertex2f(0.125, 0.2);
		glVertex2f(0.25, 0.0);
		glVertex2f(0.375, 0.2);
	glEnd();

	glBegin(GL_LINE_LOOP);
		// COLOR: Yellow for base of diamond
		glColor3f(1.0f, 1.0f, 0.0f);

		glVertex2f(0.0, -0.75);
		glVertex2f(0.5, 0.0);
		glVertex2f(-0.5, 0.0);
	glEnd();

	//ensures our objects are drawn right away
	glFlush(); 

	//if we are using double buffering
	glutSwapBuffers(); 
}

int main(int argc, char ** argv )
{
	glutInit(&argc, argv); //process arguments

	//Initialize buffers
	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE ); 
	
	//Sets some initial stuff
	glutInitWindowPosition(400, 200 ); 
	glutInitWindowSize(640, 480);

	//Creates window
	static int window = glutCreateWindow( "Welcome, IT356, Drew Martin!"); 

	//Display callback function, etc. myRender()
	glutDisplayFunc(myRender);

	//Enters main processing loop
	glutMainLoop(); 

	exit(0);
}