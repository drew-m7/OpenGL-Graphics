#include "loadShaders.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window);

//Settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;
	
//Vertex Buffer Object (VBO)
unsigned int VBO[2];

//Vertex Array Object (VAO)
unsigned int VAO[2];

//Element Buffer Object (EBO)
unsigned int EBO[2];

//Shader Program (shaderProgram)'s ID
int shaderProgram;
int shaderProgram2;

void init(void)
{
	//Return shaderProgram, which is used to set programID
	shaderProgram = loadShader("../../src/shader/vshaderEBO.glsl", "../../src/shader/fshaderEBO.glsl");
	shaderProgram2 = loadShader("../../src/shader/vshaderEBO.glsl", "../../src/shader/fshaderEBO2.glsl");

	//set up twice the verticies list and unique indicies twice to help will multiple shaders and the EBO, everything working correctly now
	//Set up vertex data (and buffer(s)) and configure vertex attributes
	float vertices[] = {
			 0.5f,  0.5f, 0.0f,  //top right  0 
			 0.5f, -0.5f, 0.0f,  //bottom right   1
			-0.5f, -0.5f, 0.0f,  //bottom left   2
			-0.5f,  0.5f, 0.0f,   //top left    3
			 0.0f, 0.5f, 0.0f,   // top middle   4
			 0.0f, -0.5f, 0.0f, // bottom middle   5
			-0.85f, 0.0f, 0.0f  //far left point   6
	};
	float vertices2[] = {
			 0.5f,  0.5f, 0.0f,  //top right  0 
			 0.5f, -0.5f, 0.0f,  //bottom right   1
			-0.5f, -0.5f, 0.0f,  //bottom left   2
			-0.5f,  0.5f, 0.0f,   //top left    3
			 0.0f, 0.5f, 0.0f,   // top middle   4
			 0.0f, -0.5f, 0.0f, // bottom middle   5
			-0.85f, 0.0f, 0.0f  //far left point   6
	};
	unsigned int indices[] = {  //note that we start from 0!
		// forms right side rectangle
		0, 1, 4,  //first Triangle
		1, 4, 5   //second Triangle
	};
	unsigned int indices2[] = {
		// forms left side rectangle and the triangle point
		2, 3, 6,  // point
		2, 3, 5,  //first triangle
		3, 4, 5   //second triangle
	};

	glGenVertexArrays(2, VAO);
	glGenBuffers(2, VBO);
	glGenBuffers(2, EBO);

	//Bind the Vertex Array Object first, 
	//then bind and set vertex buffer(s), and then configure vertex attributes(s).
	glBindVertexArray(VAO[0]);

	//Copy our vertices array in a buffer for OpenGL to use
	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[0]);

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	//Copy our index array in a element buffer for OpenGL to use
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
	
	//Then set the vertex attributes pointers
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//Uncomment this call to draw in wireframe polygons.
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	// second part
	glBindVertexArray(VAO[1]);

	//Copy our vertices array in a buffer for OpenGL to use
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[1]);

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices2), vertices2, GL_STATIC_DRAW);

	//Copy our index array in a element buffer for OpenGL to use
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices2), indices2, GL_STATIC_DRAW);

	//Then set the vertex attributes pointers
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//Uncomment this call to draw in wireframe polygons.
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

void display()
{
	//Render
	glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//Use the shader program when we want to render an object
	glUseProgram(shaderProgram);

	//Drawing code
	glBindVertexArray(VAO[0]);
	glDrawElements(GL_TRIANGLES, 15, GL_UNSIGNED_INT, 0);

	//Use the shader program when we want to render an object
	glUseProgram(shaderProgram2);

	//Drawing code
	glBindVertexArray(VAO[1]);
	glDrawElements(GL_TRIANGLES, 15, GL_UNSIGNED_INT, 0);

	//No need to unbind it every time 
	glBindVertexArray(0); 
}

int main()
{
	//glfw: initialize and configure
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	//glfw window creation
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Recitation 2: Question 2 (Drew Martin)", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	//glad: load all OpenGL function pointers
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();

	//Render loop
	while (!glfwWindowShouldClose(window))
	{
		//Input
		processInput(window);

		display();

		//glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	//Optional: de-allocate all resources once they've outlived their purpose:
	glDeleteVertexArrays(2, VAO);
	glDeleteBuffers(2, VBO);

	//glfw: terminate, clearing all previously allocated GLFW resources.
	glfwTerminate();
	return 0;
}

//Process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

//glfw: whenever the window size changed (by OS or user resize) this callback function executes
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	//Make sure the viewport matches the new window dimensions; note that width and 
	//height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

