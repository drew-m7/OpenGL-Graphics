#include "loadShaders.h"

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow *window);

//Settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;
	
//Vertex Buffer Object (VBO)
unsigned int VBO[3];

//Vertex Array Object (VAO)
unsigned int VAO[3];

//Shader Program (shaderProgram)'s ID
int programID1;
int programID2;
int programID3;

void init(void)
{
	//Return shaderProgram, which is used to set the shader program's ID
	//Used three shaders the first two are named fshaderTwoShaders1 and 2 and the third is named fshader21
	programID1 = loadShader("../../src/shader/vshaderTwoShaders.glsl", "../../src/shader/fshaderTwoShaders1.glsl");
	programID2 = loadShader("../../src/shader/vshaderTwoShaders.glsl", "../../src/shader/fshaderTwoShaders2.glsl");
	programID3 = loadShader("../../src/shader/vshaderTwoShaders.glsl", "../../src/shader/fshader21.glsl");

	//Set up vertex data (and buffer(s)) and configure vertex attributes
	float firstTriangle[] = {
		-0.9f, -0.5f, 0.0f,  //left 
		-0.0f, -0.5f, 0.0f,  //right
		-0.45f, 0.5f, 0.0f,  //top 
	};
	float secondTriangle[] = {
		0.0f, -0.5f, 0.0f,  //left
		0.9f, -0.5f, 0.0f,  //right
		0.45f, 0.5f, 0.0f   //top
	};
	float thirdTriangle[] = {
		0.0f, -0.5f, 0.0f,  
		0.45f, 0.5f, 0.0f,  
		-0.45f, 0.5f, 0.0f   
	};

	//We can also generate multiple VAOs or buffers at the same time
	glGenVertexArrays(3, VAO);
	glGenBuffers(3, VBO);

	//First triangle setup
	glBindVertexArray(VAO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(firstTriangle), firstTriangle, GL_STATIC_DRAW);
	//Vertex attributes stay the same
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//The Second triangle setup
	glBindVertexArray(VAO[1]);	//Note that we bind to a different VAO now
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);	//And a different VBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(secondTriangle), secondTriangle, GL_STATIC_DRAW);
	//Because the vertex data is tightly packed
	//We can also specify 0 as the vertex attribute's stride to let OpenGL figure it out
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//The Third triangle setup
	glBindVertexArray(VAO[2]);	//Note that we bind to a different VAO now
	glBindBuffer(GL_ARRAY_BUFFER, VBO[2]);	//And a different VBO
	glBufferData(GL_ARRAY_BUFFER, sizeof(thirdTriangle), thirdTriangle, GL_STATIC_DRAW);
	//Because the vertex data is tightly packed
	//We can also specify 0 as the vertex attribute's stride to let OpenGL figure it out
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	//Uncomment this call to draw in wireframe polygons.
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
}

void display()
{
	//Render
	glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	//When we draw the triangle we first use the vertex and orange fragment shader from the first program
	glUseProgram(programID1);
	//Draw the first triangle using the data from our first VAO
	glBindVertexArray(VAO[0]);
	glDrawArrays(GL_TRIANGLES, 0, 3);

	//Then we draw the second triangle using the data from the second VAO
	//When we draw the second triangle we want to use a different shader program so we switch 
	//to the shader program with our yellow fragment shader.
	glUseProgram(programID2);
	glBindVertexArray(VAO[1]);
	glDrawArrays(GL_TRIANGLES, 0, 3); //This call should output a second triangle	
	
	// Third triangle
	glUseProgram(programID3);
	glBindVertexArray(VAO[2]);
	glDrawArrays(GL_TRIANGLES, 0, 3); //This call should output a third triangle	

	//No need to unbind it every time 
	glBindVertexArray(0);
}

int main()
{
	//glfw: initialize and configure
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	//glfw window creation
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Recitation 2: Question 1 (Drew Martin)", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	//glad: load all OpenGL function pointers
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();

	//Render loop
	while (!glfwWindowShouldClose(window))
	{
		//Input
		processInput(window);

		display();

		//glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	//Optional: de-allocate all resources once they've outlived their purpose:
	glDeleteVertexArrays(1, VAO);
	glDeleteBuffers(1, VBO);

	//glfw: terminate, clearing all previously allocated GLFW resources.
	glfwTerminate();
	return 0;
}

//Process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void processInput(GLFWwindow *window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
}

//glfw: whenever the window size changed (by OS or user resize) this callback function executes
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	//Make sure the viewport matches the new window dimensions; note that width and 
	//height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

